package com.example.fit5046_assignment3;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.HashMap;
import java.util.List;

public class MapFragment extends Fragment implements OnMapReadyCallback {
    View map_view;
    private MapView mapView;
    private GoogleMap map;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle
            savedInstanceState) {
        map_view = inflater.inflate(R.layout.map, container, false);

        return map_view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstance) {
        super.onViewCreated(view, savedInstance);
        mapView = (MapView) map_view.findViewById(R.id.view_map);
        if (mapView != null) {
            mapView.onCreate(null);
            mapView.onResume();
            mapView.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        LatLng loc = new LatLng(Double.parseDouble(LoginActivity.latitude), Double.parseDouble(LoginActivity.longitude));
        map.addMarker(new MarkerOptions().position(loc).title("Home"));

        List<HashMap<String,String>> location = LoginActivity.cinemaLocation;
        for (int i = 0; i < location.size(); i++) {
            LatLng park = new LatLng(Double.parseDouble(location.get(i).get("lat")), Double.parseDouble(location.get(i).get("lng")));
            map.addMarker(new MarkerOptions().position(park).title(LoginActivity.allCinemaNameList.get(i)).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN)).alpha(0.7f));
        }
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(loc, 12.0f));
    }

}


