package com.example.fit5046_assignment3;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fit5046_assignment3.Class.Credentials;
import com.example.fit5046_assignment3.Class.Person;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class SignupActivity extends AppCompatActivity {

    private ScrollView scView;
    private HashMap<String, EditText> hashMap = new HashMap<String, EditText>();
    private List<String> allUserNames = new ArrayList<>();
    private Character gender = 'F';
    private String state;
    private String signup_date;
    private String DoB;
    private Integer credentialID;
    private Credentials credential;
    private Person person;
    private  TextView text_datePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        scView = (ScrollView) findViewById(R.id.sc_scrollView);
        Button date_pick = (Button) findViewById(R.id.button_datePicker);
        Button submmit = (Button) findViewById(R.id.button_submit);

        hashMap.put("et_newUserName", (EditText) findViewById(R.id.et_newUserName));
        hashMap.put("et_newPassword", (EditText) findViewById(R.id.et_newPassword));
        hashMap.put("et_confirmPassword", (EditText) findViewById(R.id.et_confirmPassword));
        hashMap.put("et_first_name", (EditText) findViewById(R.id.et_firstName));
        hashMap.put("et_last_name", (EditText) findViewById(R.id.et_lastName));
        hashMap.put("et_address", (EditText) findViewById(R.id.et_address));
        hashMap.put("et_postcode", (EditText) findViewById(R.id.et_postcode));
        text_datePicker = (TextView)findViewById(R.id.text_datepick);
        Spinner spinnerDate = (Spinner) findViewById(R.id.spinner_state);
        new AsyncGetUserName().execute();

        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGenderGroup);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton radioButton = (RadioButton) findViewById(checkedId);
                if (radioButton.getText().equals("Male")) {
                    gender = 'M';
                } else {
                    gender = 'F';
                }
            }
        });
        //state spinner
        List<String> stateList = new ArrayList<>();
        stateList.add("NSW");
        stateList.add("QLD");
        stateList.add("SA");
        stateList.add("TAS");
        stateList.add("VIC");
        stateList.add("WA");
        final ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, stateList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDate.setAdapter(spinnerAdapter);
        spinnerDate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
          @Override
          public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
              String chooseState = parent.getItemAtPosition(position).toString();
              if (chooseState != null) {
              state = chooseState;
              } else {
                  state = "";
              }
          }
          @Override
          public void onNothingSelected(AdapterView<?> parent) {
          }
        });


        //signup date & Dob picker
        date_pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int mYear = calendar.get(Calendar.YEAR);
                int mMonth = calendar.get(Calendar.MONTH);
                final int mDay = calendar.get(Calendar.DAY_OF_MONTH);
                int monthm = mMonth + 1;
                String monthNew;
                if (monthm < 10) {
                    StringBuffer str = new StringBuffer("0");
                    monthNew = str.append(monthm).toString();
                } else {
                    monthNew = String.valueOf(monthm);
                }
                String dayNew = "";
                if (mDay < 10) {
                    StringBuffer str = new StringBuffer("0");
                    dayNew = str.append(mDay).toString();
                } else {
                    dayNew = String.valueOf(mDay);
                }
                String dateNew = mYear + "-" + monthNew + "-" + dayNew;
                StringBuffer dateTT = new StringBuffer(dateNew);
                signup_date = dateTT.append("T00:00:00+10:00").toString();

                DatePickerDialog picker = new DatePickerDialog(SignupActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String monthString;
                        int mmonth = month + 1;
                        if (mmonth < 10) {
                            StringBuffer str = new StringBuffer("0");
                            monthString = str.append(mmonth).toString();
                        } else {
                            monthString = String.valueOf(mmonth);
                        }
                        String dayString;
                        if (dayOfMonth < 10) {
                            StringBuffer str = new StringBuffer("0");
                            dayString = str.append(dayOfMonth).toString();
                        } else {
                            dayString = String.valueOf(dayOfMonth);
                        }
                        String dob = year + "-" + monthString + "-" + dayString;
                        text_datePicker.setText(dob);
                        StringBuffer stringBuffer = new StringBuffer(dob);
                        DoB = stringBuffer.append("T00:00:00+10:00").toString();
                    }
                }, mYear, mMonth, mDay);

                DatePicker dp = picker.getDatePicker();
                dp.setMaxDate(System.currentTimeMillis());
                picker.show();
            }
        });

        submmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean flag = true;
                String newUsernameGet = hashMap.get("et_newUserName").getText().toString();
                for (String i : allUserNames) {
                    if (newUsernameGet.equals(i)) {
                        flag = false;
                        hashMap.get("et_newUserName").setError("Sorry, the username is existed");
                    }
                }

                if (hashMap.get("et_newPassword").getText().toString().equals(hashMap.get("et_confirmPassword").getText().toString())) {
                    if (flag == true) {
                        person = new Person();
                        person.setFirstName(hashMap.get("et_first_name").getText().toString());
                        person.setSurname(hashMap.get("et_last_name").getText().toString());
                        person.setGender(gender);
                        person.setDob(DoB);
                        person.setAddress(hashMap.get("et_address").getText().toString());
                        person.setState(state);
                        person.setPostcode(hashMap.get("et_postcode").getText().toString());

                        credential = new Credentials();
                        credential.setUsername(hashMap.get("et_newUserName").getText().toString());
                        String passwordHash = getSHA256StrJava(hashMap.get("et_newPassword").getText().toString());
                        credential.setPasswordHash(passwordHash);
                        credential.setSignupDate(signup_date);
                        new AsyncGetMaxCredentialsID().execute();
                        Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(SignupActivity.this, "Please check your information again", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(SignupActivity.this, "The password is not match", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private class AsyncGetUserName extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            URL url = null;
            HttpURLConnection conn = null;
            String textResult = "";
            final String methodPath = "assign1.credentials/getAllUsername";
            try {
                url = new URL(LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            try {
                JSONArray jsonArray = new JSONArray(textResult);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                    String getUsername = jsonObject.getString("username");
                    allUserNames.add(getUsername);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return textResult;
        }
    }


    // getcredential id
    private class AsyncGetMaxCredentialsID extends AsyncTask<Credentials, Void, Integer> {
        @Override
        protected Integer doInBackground(Credentials... credentials) {
            String textResult = " ";
            URL url = null;
            HttpURLConnection conn = null;
            final String methodPath = "assign1.credentials/getNewCredentialsID";
            try {
                url = new URL(LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }

            try {
                JSONObject jsonObject = new JSONObject(textResult);
                String getCredentialID = jsonObject.getString("credentialId");
                credentialID = Integer.valueOf(getCredentialID) + 1;
                credential.setCredentialId(credentialID);
                person.setCredentialId(credential);
                person.setPersonId(credentialID);

                new AsyncPostCredential().execute(credential);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return credentialID;
        }
    }

    private class AsyncPostCredential extends AsyncTask<Credentials, Void, Credentials> {
        @Override
        protected Credentials doInBackground(Credentials... credentials) {
            URL url = null;
            HttpURLConnection conn = null;
            String textResult = "";
            final String methodPath = "assign1.credentials/";
            try {
                Gson gson = new Gson();
                String stringJson = gson.toJson(credentials[0]);
                String replaceJson = stringJson.replace("[", "").replace("]", "");
                url = new URL(LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setFixedLengthStreamingMode(stringJson.getBytes().length);
                conn.setRequestProperty("Content-Type", "application/json");
                PrintWriter writer = new PrintWriter(conn.getOutputStream());
                writer.print(stringJson);
                writer.flush();
                writer.close();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Credentials credentials) {
            super.onPostExecute(credentials);
            AsyncPostPerson asyncPostPerson = new AsyncPostPerson();
            asyncPostPerson.execute(person);
        }
    }


    private class AsyncPostPerson extends AsyncTask<Person, Void, Person> {
        @Override

        protected Person doInBackground(Person... persons) {

            URL url = null;
            HttpURLConnection conn = null;
            String textResult = "";
            final String methodPath = "assign1.person/";
            try {
                Gson gson = new Gson();
                String stringJson = gson.toJson(persons[0]);
                String replaceJson = stringJson.replace("[", "").replace("]", "");
                url = new URL(LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setFixedLengthStreamingMode(replaceJson.getBytes().length);
                conn.setRequestProperty("Content-Type", "application/json");
                PrintWriter writer = new PrintWriter(conn.getOutputStream());
                writer.print(replaceJson);
                writer.flush();
                writer.close();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            return persons[0];
        }


        @Override
        protected void onPostExecute(Person person) {
            super.onPostExecute(person);
            Toast.makeText(SignupActivity.this,"Registered!!!!!",Toast.LENGTH_SHORT).show();
        }
    }
    private String getSHA256StrJava(String str) {
        MessageDigest messageDigest;
        String encodeStr = "";
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(str.getBytes("UTF-8"));
            encodeStr = byte2Hex(messageDigest.digest());
        }catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return encodeStr;
    }
    private String byte2Hex(byte[] bytes) {
        StringBuilder stringBuffer = new StringBuilder();
        String temp = null;
        for (int i = 0; i < bytes.length; i++) {
            temp = Integer.toHexString(bytes[i] & 0xFF);
            if (temp.length() == 1) {
                stringBuffer.append("0");
            }
            stringBuffer.append(temp);
        }
        return stringBuffer.toString();
    }
}
