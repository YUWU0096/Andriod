package com.example.fit5046_assignment3.database;

import android.app.Application;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class WatchListViewModel extends ViewModel {
    private WatchListRepository wRepository;
    private MutableLiveData<List<WatchList>> allWatchLists;
    public WatchListViewModel () {
        allWatchLists=new MutableLiveData<>();
    }
    public void setWatchListsF(List<WatchList> watchLists) {
        allWatchLists.setValue(watchLists);
    }
    public LiveData<List<WatchList>> getAllWatchLists(String personID) {
        return wRepository.getAllWatchList(personID);
    }
    public void initalizeVars(Application application){
        wRepository = new WatchListRepository(application);
    }
    public void insert(WatchList watchList) {
        wRepository.insert(watchList);
    }
    public void insertAll(WatchList... watchLists) {
        wRepository.insertAll(watchLists);
    }
    public void deleteAll() {
        wRepository.deleteAll();
    }
    public void delete(WatchList watchList){wRepository.delete(watchList);}

    public void insertAll(WatchList watchList) {
        wRepository.delete(watchList);
    }
    public void update(WatchList... watchLists) {
        wRepository.updateWatchList(watchLists);
    }
    public WatchList insertAll(int id) {
        return wRepository.findByID(id);
    }
    public WatchList findByID(int watchID){
        return wRepository.findByID(watchID);
    }
    public void deleteByWatchID(int watchID){
        wRepository.deleteByWatchID(watchID);
    }
    public List<WatchList> getWatchListByPersonID(String personID){return wRepository.getAllWatchListByPersonID(personID);};
}
