package com.example.fit5046_assignment3;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.fit5046_assignment3.database.WatchList;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class MovieViewFragment extends Fragment {
    View movieView;
    private TextView text_movieName;
    private TextView text_movieReleaseDate;
    private TextView text_ratingScore;
    private TextView text_movieOverview;
    private String movieID;
    private String movieName;
    private ListView listView_genres;
    private ListView listView_country;
    private ListView listView_cast;
    private ListView listView_director;
    private List<HashMap<String,String>> listArrayGenre = new ArrayList<HashMap<String,String>>();
    private List<HashMap<String,String>> listArrayCountry = new ArrayList<HashMap<String,String>>();
    private List<HashMap<String,String>> listArrayCast = new ArrayList<HashMap<String,String>>();
    private List<HashMap<String,String>> listArrayDirector = new ArrayList<HashMap<String,String>>();

    private Button button_addToWatchList;
    private Button button_adddToMemoir;
    private RatingBar ratingBar;
   // private int watchid; //////
    private String imageURL;
    private String result;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        movieView = inflater.inflate(R.layout.fragment_movie_view, container, false);
        text_movieName = (TextView) movieView.findViewById(R.id.text_moviename_view);
        text_movieReleaseDate=(TextView) movieView.findViewById(R.id.text_movieReleaseDate_view);

        text_ratingScore =(TextView)movieView.findViewById(R.id.text_movieRatingscore_view);
        text_movieOverview = (TextView) movieView.findViewById(R.id.text_movieOverview_view);
        listView_genres = (ListView) movieView.findViewById(R.id.listView_movieGenre_view);
        listView_country = (ListView) movieView.findViewById(R.id.listView_movieCountry_view);
        listView_cast = (ListView)movieView.findViewById(R.id.listView_movieCast_view);
        listView_director = (ListView) movieView.findViewById(R.id.listView_moveiDirector_view);
        button_adddToMemoir=(Button) movieView.findViewById(R.id.button_addToMemoir_view);
        button_addToWatchList=(Button)movieView.findViewById(R.id.button_addToWatchlist_view);
        ratingBar = (RatingBar) movieView.findViewById(R.id.ratingbar_movieRatingbar_view);

        if(getArguments()!=null){
            movieID = getArguments().getString("movieId");
            movieName = getArguments().getString("movieName");
            if(getArguments().getString("flag").equals("false")){
                button_addToWatchList.setVisibility(View.INVISIBLE);
            }
            text_movieName.setText(movieName);
            new AsyncGetMovieInformation().execute(movieID);
            button_addToWatchList.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new checkMovieExistWatchlist().execute(String.valueOf(LoginActivity.uid));
                }
            });

            button_adddToMemoir.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Fragment fragment = new AddMemoirFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("movieId", movieID);
                    bundle.putString("movieName",text_movieName.getText().toString());
                    bundle.putString("imageURL",imageURL);
                    bundle.putString("releaseDate", text_movieReleaseDate.getText().toString());
                    fragment.setArguments(bundle);
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.content_frame,fragment).commit();
                }
            });
        }
        return movieView;
    }

    private class AsyncGetMovieInformation extends AsyncTask<String,Void,String>{
        @Override
        protected String doInBackground(String... strings) {
           String textResult = SearchMovieAPI.movieInformation(strings[0]);
            return textResult;
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            result=s;
            new AsyncGetMovieCredits().execute(movieID);

        }
    }
    private class AsyncGetMovieCredits extends  AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... strings) {
            return SearchMovieAPI.movieCredits(strings[0]);
        }
        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            HashMap<String,Object> hashMap = SearchMovieAPI.MovieCombine(result,s);
            text_movieReleaseDate.setText(hashMap.get("release_date").toString());
            text_movieOverview.setText(hashMap.get("orverview").toString());
            imageURL = hashMap.get("imageURL").toString();

            Object objectGenres =hashMap.get("genres");
            List<String> genresList = (ArrayList) objectGenres;
            for(int a = 0; a < genresList.size();a++){
                HashMap<String,String> genresHashMap = new HashMap<>();
                genresHashMap.put("genresList",genresList.get(a));
                listArrayGenre.add(genresHashMap);
            }
            String[] genresHeader = new String[]{"genresList"};
            int[] genresCell = new int[]{R.id.textview_genresView};
            SimpleAdapter simpleAdapter = new SimpleAdapter(MovieViewFragment.this.getActivity(),listArrayGenre,R.layout.movie_listview_view_genres,genresHeader,genresCell);
            listView_genres.setAdapter(simpleAdapter);

            //country
            Object objectCountry =hashMap.get("country");
            List<String> countryList = (ArrayList) objectCountry;
            for(int b = 0; b < countryList.size();b++){
                HashMap<String,String> countryHashMap = new HashMap<>();
                countryHashMap.put("countryList",countryList.get(b));
                listArrayCountry.add(countryHashMap);
            }
            String[] countryHeader = new String[]{"countryList"};
            int[] countryCell = new int[]{R.id.textview_countryView};
            SimpleAdapter simpleAdapter1 = new SimpleAdapter(MovieViewFragment.this.getActivity(),listArrayCountry,R.layout.movie_listview_view_country,countryHeader,countryCell);
            listView_country.setAdapter(simpleAdapter1);
            //cast
            Object objectCast =hashMap.get("cast");
            List<String> castList = (ArrayList) objectCast;
            for(int c = 0; c < castList.size();c++){
                HashMap<String,String> castHashMap = new HashMap<>();
                castHashMap.put("castList",castList.get(c));
                listArrayCast.add(castHashMap);
            }
            String[] castHeader = new String[]{"castList"};
            int[] castCell = new int[]{R.id.textview_cast};
            SimpleAdapter simpleAdapter2 = new SimpleAdapter(MovieViewFragment.this.getActivity(),listArrayCast,R.layout.movie_listview_view_cast,castHeader,castCell);
            listView_cast.setAdapter(simpleAdapter2);
            //directors
            Object objectDirectors =hashMap.get("Directors");
            List<String> directorList = (ArrayList) objectDirectors;
            for(int d = 0; d < directorList.size();d++){
                HashMap<String,String> directorHashMap = new HashMap<>();
                directorHashMap.put("directorList",directorList.get(d));
                listArrayDirector.add(directorHashMap);
            }
            String[] directorHeader = new String[]{"directorList"};
            int[] directorCell = new int[]{R.id.textview_director};
            SimpleAdapter simpleAdapter3= new SimpleAdapter(MovieViewFragment.this.getActivity(),listArrayDirector,R.layout.movie_listview_view_director,directorHeader,directorCell);
            listView_director.setAdapter(simpleAdapter3);

            Float f = Float.parseFloat(hashMap.get("rating_score").toString());
            text_ratingScore.setText(hashMap.get("rating_score").toString());
            ratingBar.setRating(f);
        }
    }

    private class checkMovieExistWatchlist extends AsyncTask<String,Void,List<WatchList>>{

        @Override
        protected List<WatchList> doInBackground(String... strings) {
            List<WatchList> watchLists = MenuFragment.watchListViewModel.getWatchListByPersonID(strings[0]);

            return watchLists;
        }

        @Override
        protected void onPostExecute(List<WatchList> watchLists) {
            boolean check = true;
            super.onPostExecute(watchLists);
            for(WatchList watchList1 :watchLists){
                if(watchList1.getMovieID().equals(movieID)){
                    Toast.makeText(movieView.getContext(),"The movie is existed in watchlist", Toast.LENGTH_SHORT).show();
                    check = false;
                    break;
                }
            }

            if(check==true){
                Date currentDate = new Date();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
                SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
                String dateAdded =dateFormat.format(currentDate.getTime());
                String timeAdded =timeFormat.format(currentDate.getTime());
                WatchList watchList = new WatchList();
                watchList.setDateAdded(dateAdded);
                watchList.setTimeAdded(timeAdded);
                watchList.setMovieID(movieID);
                watchList.setMovieName(movieName);
                watchList.setReleaseDate(text_movieReleaseDate.getText().toString());
                watchList.setPersonID(LoginActivity.uid.toString());
                MenuFragment.watchListViewModel.insert(watchList);
                Toast.makeText(movieView.getContext(),"Movie is added into watchlist",Toast.LENGTH_SHORT).show();
            }
        }
    }

}
