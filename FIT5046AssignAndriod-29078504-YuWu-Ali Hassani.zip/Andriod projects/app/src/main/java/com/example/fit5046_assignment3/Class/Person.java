package com.example.fit5046_assignment3.Class;

import com.example.fit5046_assignment3.Class.Credentials;

public class Person {
    private Integer personId;
    private String firstName;
    private String surname;
    private Character gender;
    private String dob;
    private String address;
    private String state;
    private String postcode;
    private Credentials credentialId;



    public Integer getPersonId() {
        return personId;
    }

    public void setPersonId(Integer personId) {
        this.personId = personId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public Character getGender() {
        return gender;
    }

    public void setGender(Character gender) {
        this.gender = gender;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPostcode() {
        return postcode;
    }

    public void setPostcode(String postcode) {
        this.postcode = postcode;
    }

    public Credentials getCredentialId() {
        return credentialId;
    }

    public void setCredentialId(Credentials credentialId) {
        this.credentialId = credentialId;
    }
}
