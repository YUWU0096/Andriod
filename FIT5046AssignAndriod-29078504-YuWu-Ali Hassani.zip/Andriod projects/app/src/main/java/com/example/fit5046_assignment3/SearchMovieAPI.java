package com.example.fit5046_assignment3;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class SearchMovieAPI {
    private static String apiKey = "19239319af2fe642a4c84d1076c808b1";
    public static String searchMovie(String searchtext) {
        searchtext = searchtext.trim().replace(" ", "%20");
        URL url = null;
        HttpURLConnection connection = null;
        String textResult = "";
        try {
            url = new URL("https://api.themoviedb.org/3/search/movie?api_key=" + apiKey + "&language=en-US&query=" + searchtext + "&page=1&include_adult=false");
            connection = (HttpURLConnection) url.openConnection();
            connection.setReadTimeout(10000);
            connection.setConnectTimeout(15000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            Scanner inStream = new Scanner(connection.getInputStream());
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.disconnect();
        }
        return textResult;
    }
    public static List<String> getSnippet(String result){
        List<String> snippet = new ArrayList<>();
        try{
            JSONObject jsonObject = new JSONObject(result);
            JSONArray jsonArray = jsonObject.getJSONArray("results");
            if(jsonArray != null && jsonArray.length() > 0) {
               for (int i = 0; i < jsonArray.length();i++){
                   JSONObject jsonObject1 = (JSONObject) jsonArray.get(i);
                   if(jsonObject1.getString("title").isEmpty()||
                      jsonObject1.getString("release_date").isEmpty()||
                      jsonObject1.getString("poster_path").isEmpty()||
                      jsonObject1.getString("id").isEmpty()){
                       break;
                   }else {
                       snippet.add(jsonObject1.getString("title"));
                       snippet.add(jsonObject1.getString("release_date"));
                       snippet.add(jsonObject1.getString("poster_path"));
                       snippet.add(jsonObject1.getString("id"));
                   }
               }
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    return snippet;
    }
    //get movie details

    public static String movieInformation(String moviID){
        URL url = null;
        HttpURLConnection connection = null;
        String textResult = "";
        try {
            url = new URL("https://api.themoviedb.org/3/movie/"+moviID+"?api_key=" + apiKey + "&language=en-US");
            connection = (HttpURLConnection) url.openConnection();
            connection.setReadTimeout(10000);
            connection.setConnectTimeout(15000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            Scanner inStream = new Scanner(connection.getInputStream());
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.disconnect();
        }
        return textResult;
    }
    //get movie cast
    public static String movieCredits(String moviID){
        URL url = null;
        HttpURLConnection connection = null;
        String textResult = "";
        try {

            url = new URL("https://api.themoviedb.org/3/movie/"+moviID+"/credits?api_key=" + apiKey);
            connection = (HttpURLConnection) url.openConnection();
            connection.setReadTimeout(10000);
            connection.setConnectTimeout(15000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            Scanner inStream = new Scanner(connection.getInputStream());
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.disconnect();
        }
        return textResult;
    }

    public static HashMap<String,Object> MovieCombine(String textResult, String textResult1) {
        HashMap<String, Object> hashMap = new HashMap<>();

        try {
            //get movie detail
            JSONObject jsonObject = new JSONObject(textResult);
            hashMap.put("release_date", jsonObject.getString("release_date"));
            hashMap.put("orverview", jsonObject.getString("overview"));
            hashMap.put("imageURL", jsonObject.getString("poster_path"));
            hashMap.put("rating_score", jsonObject.getString("vote_average"));

            JSONArray genresArray = jsonObject.getJSONArray("genres");
            List<String> genresList = new ArrayList<>();
            for(int j =0; j < genresArray.length();j++){
                JSONObject genresJSONObject = genresArray.getJSONObject(j);
                genresList.add(genresJSONObject.getString("name"));
            }
            hashMap.put("genres", genresList);

            JSONArray countryArray = jsonObject.getJSONArray("production_countries");
            List<String> countryList = new ArrayList<>();
            for(int k=0;k<countryArray.length();k++){
                JSONObject countryJSONObject = countryArray.getJSONObject(k);
                countryList.add(countryJSONObject.getString("name"));
            }
            hashMap.put("country", countryList);

            // get movie credit
            JSONObject jsonObject1 = new JSONObject(textResult1);
            JSONArray castArray = jsonObject1.getJSONArray("cast");
            List<String> castList = new ArrayList<>();
            for (int i = 0; i < castArray.length(); i++) {
                    JSONObject castJSONObject = castArray.getJSONObject(i);
                    castList.add(castJSONObject.getString("name"));
            }
            hashMap.put("cast",castList);

            JSONArray crewArray = jsonObject1.getJSONArray("crew");
            List<String> crewList = new ArrayList<>();
            for (int m =0;m<crewArray.length();m++){
                JSONObject crewJSONObject = crewArray.getJSONObject(m);
                if(crewJSONObject.getString("job").equals("Director")){
                    crewList.add(crewJSONObject.getString("name"));
                }
            }
            hashMap.put("Directors",crewList);
        } catch (Exception e) {

        }
        return hashMap;
    }
}
