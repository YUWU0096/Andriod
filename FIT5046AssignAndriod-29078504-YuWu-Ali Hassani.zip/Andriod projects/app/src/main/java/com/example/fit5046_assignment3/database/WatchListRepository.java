package com.example.fit5046_assignment3.database;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;

public class WatchListRepository {

        private WatchListDAO dao;
        private LiveData<List<WatchList>> allWatchList;
        private WatchList watchList;
        private List<WatchList> watchListList;

        public WatchListRepository(Application application){
            WatchListDB db = WatchListDB.getInstance(application);
            dao=db.watchListDAO();
        }
        public LiveData<List<WatchList>> getAllWatchList(String personID) {
            allWatchList = dao.findByPersonID(personID);
            return allWatchList;
        }
        public List<WatchList> getAllWatchListByPersonID(String personID){
            watchListList =dao.findByPersonIDList(personID);
            return watchListList;

        }
        public void insert(final WatchList watchList){
            WatchListDB.databaseWriteExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    dao.insert(watchList);
                }
            });
        }
        public void deleteAll(){
            WatchListDB.databaseWriteExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    dao.deleteAll();
                }
            });
        }
        public void delete(final WatchList watchList){
            WatchListDB.databaseWriteExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    dao.delete(watchList);
                }
            });
        }
        public void deleteByWatchID(final int watchID){
            WatchListDB.databaseWriteExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    dao.deleteByWatchID(watchID);
                }
            });
        }
        public void insertAll(final WatchList... watchLists){
            WatchListDB.databaseWriteExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    dao.insertAll(watchLists);
                }
            });
        }
        public void updateWatchList(final WatchList... watchLists){
            WatchListDB.databaseWriteExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    dao.updateWatchList(watchLists);
                }
            });
        }

        public WatchList findByID(final int personID){
            WatchListDB.databaseWriteExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    WatchList runWatchList= dao.findByID(personID);
                    setWatchList(runWatchList);
                }
            });
            return watchList;
        }

        public void setWatchList(WatchList watchList){
            this.watchList=watchList;
        }


}
