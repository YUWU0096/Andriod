package com.example.fit5046_assignment3;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.fit5046_assignment3.Class.Cinema;
import com.example.fit5046_assignment3.Class.Memoir;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class AddMemoirFragment extends Fragment {
    private View addMemoirView;
    private TextView textView_movieName;
    private TextView textView_releaseDate;
    private ImageView imageView_movieImage;
    private Button button_watchDate;
    private Button button_watchTime;
    private TextView textView_watchDate;
    private TextView textView_watchTime;
    private Spinner spinner_cinema;
    private String movieName;
    private String releaseDate;
    private String watchDate;
    private String watchTime;
    private List<String> cinemalist = new ArrayList<>();
    private List<Cinema> arrayListCinema = new ArrayList<>();
    private String imagePath;
    private TextView textView_setRatingScore;
    private String imageURL;
    private Cinema cinema =  new Cinema();
    private EditText edit_comment;
    private Integer cinemaID;
    private Integer memoirID;
    private Memoir memoir;
    private Button button_cinemaAdd;
    private String movieID;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        addMemoirView = inflater.inflate(R.layout.movie_memoir_addmemoir, container, false);
        textView_movieName = (TextView) addMemoirView.findViewById(R.id.text_addMemoir_movieName);
        textView_releaseDate = (TextView) addMemoirView.findViewById(R.id.text_addMemoir_releaseDate);
        imageView_movieImage = (ImageView) addMemoirView.findViewById(R.id.image_movie);
        button_watchDate = (Button) addMemoirView.findViewById(R.id.button_addMemoir_datePicker);
        button_watchTime = (Button) addMemoirView.findViewById(R.id.button_addMemoir_timePicker);
        textView_watchDate = (TextView) addMemoirView.findViewById(R.id.text_addMemoir_datepick);
        textView_watchTime =(TextView) addMemoirView.findViewById(R.id.text_addMemoir_timepick);
        spinner_cinema = (Spinner) addMemoirView.findViewById(R.id.spinner_addMemoir_cinemasp);
        RatingBar ratingBar = (RatingBar) addMemoirView.findViewById(R.id.ratingbar_addMemoir_ratingbar);
        textView_setRatingScore=(TextView) addMemoirView.findViewById(R.id.text_addMemoir_RatingScore);
        edit_comment = (EditText) addMemoirView.findViewById(R.id.editText_addMemoir_comment);
        button_cinemaAdd = (Button) addMemoirView.findViewById(R.id.button_addMemoir_addNewCinema);
        Button button_addtoMemoir =(Button) addMemoirView.findViewById(R.id.button_addMemoir_addtomemoir);

        if(getArguments()!=null){
            textView_movieName.setText(getArguments().getString("movieName"));
            textView_releaseDate.setText(getArguments().getString("releaseDate"));
            movieID = getArguments().getString("movieId");
            imagePath = getArguments().getString("imageURL");
            imageURL = "https://image.tmdb.org/t/p/w600_and_h900_bestv2" + imagePath;
            new getMovieImage().execute(imageURL);
        }
        new getCinemaList().execute();

        button_cinemaAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new AddCinemaFragment();
                Bundle bundle = new Bundle();
                bundle.putString("movieId", movieID);
                bundle.putString("movieName",textView_movieName.getText().toString());
                bundle.putString("imageURL",imagePath);
                bundle.putString("releaseDate", textView_releaseDate.getText().toString());
                fragment.setArguments(bundle);
                FragmentManager fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame,fragment).commit();
            }
        });
       button_watchDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Calendar calendar = Calendar.getInstance();
                int calendarYear = calendar.get(Calendar.YEAR);
                int calendarMonth = calendar.get(Calendar.MONTH);
                final int calendarDay = calendar.get(Calendar.DAY_OF_MONTH);


                StringBuffer dateTT = new StringBuffer(textView_releaseDate.getText().toString());
                 releaseDate = dateTT.append("T00:00:00+10:00").toString();

                DatePickerDialog picker = new DatePickerDialog(addMemoirView.getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String monthString;
                        int mmonth = month + 1;
                        if (mmonth < 10) {
                            StringBuffer str = new StringBuffer("0");
                            monthString = str.append(mmonth).toString();
                        } else {
                            monthString = String.valueOf(mmonth);
                        }
                        String dayString;
                        if (dayOfMonth < 10) {
                            StringBuffer str = new StringBuffer("0");
                            dayString = str.append(dayOfMonth).toString();
                        } else {
                            dayString = String.valueOf(dayOfMonth);
                        }
                        String dateSelected = year + "-" + monthString + "-" + dayString;
                        textView_watchDate.setText(dateSelected);
                        StringBuffer stringBuffer = new StringBuffer(dateSelected);
                        watchDate = stringBuffer.append("T00:00:00+10:00").toString();
                    }
                }, calendarYear, calendarMonth, calendarDay);

                DatePicker dp = picker.getDatePicker();
                dp.setMaxDate(System.currentTimeMillis());
                picker.show();
            }
       });
       button_watchTime.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Calendar calendar = Calendar.getInstance();
               int hour = calendar.get(Calendar.HOUR_OF_DAY);
               int min = calendar.get(Calendar.MINUTE);
               TimePickerDialog timePickerDialog = new TimePickerDialog(addMemoirView.getContext(), new TimePickerDialog.OnTimeSetListener() {
                   @Override
                   public void onTimeSet(TimePicker view, int hourOfDay, int minute) {

                       String hourString ;
                       if (hourOfDay < 10) {
                           StringBuffer str = new StringBuffer("0");
                           hourString = str.append(hourOfDay).toString();
                       } else {
                           hourString = String.valueOf(hourOfDay);
                       }

                       String minString;
                       if (minute < 10) {
                           StringBuffer str = new StringBuffer("0");
                           minString = str.append(minute).toString();
                       } else {
                           minString = String.valueOf(minute);
                       }

                       StringBuffer stringBuffer1 = new StringBuffer();
                       String time = hourString + ":" + minString + ":00" ;
                       watchTime = stringBuffer1.append("1970-01-01T"+ time+"+08:00").toString();
                       textView_watchTime.setText(time);
                   }
               },hour,min,true);
               timePickerDialog.show();
           }
       });

       ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
           @Override
           public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
               textView_setRatingScore.setText(String.valueOf(rating));
           }
       });


       button_addtoMemoir.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               if (textView_watchDate.getText().toString().isEmpty()||
                       textView_watchTime.getText().toString().isEmpty()||
                    edit_comment.getText().toString().isEmpty()||
               textView_setRatingScore.getText().toString().isEmpty()){

                   Toast.makeText(addMemoirView.getContext(),"Please enter all memoir information",Toast.LENGTH_SHORT).show();;
               }   else{
                   memoir = new Memoir();
                   memoir.setMovieName(textView_movieName.getText().toString());
                   memoir.setCinemaId(cinema);
                   memoir.setMovieReleaseDate(releaseDate);
                   memoir.setRatingScore(textView_setRatingScore.getText().toString());
                   memoir.setWatchDate(watchDate);
                   memoir.setWatchTime(watchTime);
                   memoir.setComment(edit_comment.getText().toString());
                   memoir.setPersonId(LoginActivity.personData);
                   new getMemoirID().execute();
               }
           }
       });
        return addMemoirView;
    }

    public class getMovieImage extends AsyncTask<String,Void, Bitmap>{
        @Override
        protected Bitmap doInBackground(String... strings) {
            Bitmap bitmap = null;
            try {
                URL url = new URL(strings[0]);
                InputStream inputStream = url.openStream();
                bitmap = BitmapFactory.decodeStream(inputStream);
                inputStream.close();
                return bitmap;
            }  catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            imageView_movieImage.setImageBitmap(bitmap);
        }
    }

    private class getCinemaList extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            URL url = null;
            HttpURLConnection conn = null;
            String textResult = "";

            final String methodPath = "assign1.cinema";
            try {
                url = new URL (LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            return textResult;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                JSONArray jsonArray = new JSONArray(s);
                for(int i =0; i< jsonArray.length();i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    String nameAndpostcode =jsonObject.getString("cinemaName") + "/" +
                                            jsonObject.getString("cinemaPostcode");
                    cinemalist.add(nameAndpostcode);

                    Cinema cinema1 = new Cinema();
                    cinema1.setCinemaId(Integer.valueOf(jsonObject.getString("cinemaId")));
                    cinema1.setCinemaName(jsonObject.getString("cinemaName"));
                    cinema1.setCinemaPostcode(jsonObject.getString("cinemaPostcode"));
                    arrayListCinema.add(cinema1);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(addMemoirView.getContext(),android.R.layout.simple_spinner_item,cinemalist);
            arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner_cinema.setAdapter(arrayAdapter);
            spinner_cinema.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    cinema = arrayListCinema.get(position);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

        }
    }


    private class AsyncPostMemoir extends AsyncTask<Memoir, Void, Memoir> {
        @Override

        protected Memoir doInBackground(Memoir... memoirs) {
            URL url = null;
            HttpURLConnection conn = null;
            String textResult = "";
            final String methodPath = "assign1.memoir/";
            try {
                Gson gson = new Gson();
                String stringJson = gson.toJson(memoirs[0]);
                String replaceJson = stringJson.replace("[", "").replace("]", "");
                url = new URL(LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setFixedLengthStreamingMode(replaceJson.getBytes().length);
                conn.setRequestProperty("Content-Type", "application/json");
                PrintWriter writer = new PrintWriter(conn.getOutputStream());
                writer.print(replaceJson);
                writer.flush();
                writer.close();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            return memoirs[0];
        }
        @Override
        protected void onPostExecute(Memoir memoir) {
            super.onPostExecute(memoir);
            Toast.makeText(addMemoirView.getContext(),"The memoir is added!!!!",Toast.LENGTH_SHORT).show();
        }
    }

    private class getMemoirID extends AsyncTask<Memoir, Void, Integer> {
        @Override
        protected Integer doInBackground(Memoir... cinemas) {
            String textResult = " ";
            URL url = null;
            HttpURLConnection conn = null;
            final String methodPath = "assign1.memoir/getNewMemoirID";
            try {
                url = new URL(LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }

            try {
                JSONObject jsonObject = new JSONObject(textResult);
                String getMemoirID = jsonObject.getString("memoirId");
                memoirID = Integer.valueOf(getMemoirID) + 1;
                memoir.setMemoirId(memoirID);
                System.out.println(memoir);
                new AsyncPostMemoir().execute(memoir);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return memoirID;
        }
    }



}
