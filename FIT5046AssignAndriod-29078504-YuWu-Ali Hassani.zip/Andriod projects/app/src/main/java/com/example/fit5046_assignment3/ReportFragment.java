package com.example.fit5046_assignment3;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Scanner;

public class ReportFragment extends Fragment {

    View reportView;
    private Button bt_report_start;
    private Button bt_report_end;
    private TextView te_startdate;
    private TextView te_enddate;
    private Button bt_pie_submmit;
    private String datePick;
    private PieChart pieChart;
    private Spinner sp_bar;
    private String yearChoose;
    private Button bt_bar_submit;
    private List<Integer> yValueList = new ArrayList<>();
    private List<String> xValueList = new ArrayList<>();
    private List<IBarDataSet> barDataSets = new ArrayList<>();
    private LinkedHashMap<String,List<Integer>> dataLinkedHashmap = new LinkedHashMap<>();
    private BarChart barChart;

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        reportView = inflater.inflate(R.layout.report, container, false);
        bt_report_start = reportView.findViewById(R.id.button_report_start);
        bt_report_end = reportView.findViewById(R.id.button_report_end);
        te_startdate = reportView.findViewById(R.id.text_report_startdate);
        te_enddate = reportView.findViewById(R.id.text_report_endtdate);
        bt_pie_submmit = reportView.findViewById(R.id.pie_submit);
        pieChart = reportView.findViewById(R.id.piechart);
        sp_bar = reportView.findViewById(R.id.spinner_year);
        bt_bar_submit = reportView.findViewById(R.id.chart_submit);
        barChart = reportView.findViewById(R.id.bar_chart);
        bt_report_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePicker(te_startdate);
            }
        });
        bt_report_end.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePicker(te_enddate);
            }
        });
        bt_pie_submmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new numberOfMoviePerPostCode().execute(te_startdate.getText().toString(),te_enddate.getText().toString());
            }
        });
        List<String> yearList = new ArrayList<>();
        yearList.add("2020");yearList.add("2019");yearList.add("2018");yearList.add("2017");yearList.add("2016");yearList.add("2015");
        final ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(ReportFragment.this.getActivity(), android.R.layout.simple_spinner_item, yearList);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp_bar.setAdapter(spinnerAdapter);
        sp_bar.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedyear = parent.getItemAtPosition(position).toString();
                if (selectedyear != null) {
                    yearChoose = selectedyear;
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                yearChoose = "2020";
            }
        });
        bt_bar_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new numberOfMoviesWatchedPerMonth().execute(yearChoose);
            }
        });


    return reportView;
    }



    public void datePicker(final TextView tv){

        Calendar calendar = Calendar.getInstance();
        int calendarYear = calendar.get(Calendar.YEAR);
        int calendarMonth = calendar.get(Calendar.MONTH);
        final int calendarDay = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePicker = new DatePickerDialog(reportView.getContext(), new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                String mon = "";
                int month = monthOfYear + 1;
                if (month < 10) {
                    StringBuffer str = new StringBuffer("0");
                    mon = str.append(month).toString();
                } else {
                    mon = String.valueOf(month);
                }
                String day = "";
                if (dayOfMonth < 10) {
                    StringBuffer str = new StringBuffer("0");
                    day = str.append(dayOfMonth).toString();
                } else {
                    day = String.valueOf(dayOfMonth);
                }
                String date = year + "-" + mon + "-" + day;
                tv.setText(date);


            }
        }, calendarYear, calendarMonth, calendarDay);
        DatePicker dp = datePicker.getDatePicker();
        dp.setMaxDate(System.currentTimeMillis());
        datePicker.show();
    }

    private class numberOfMoviePerPostCode extends AsyncTask<String, Void, List<PieEntry>> {
        @Override
        protected List<PieEntry> doInBackground(String... strings) {
            String textResult = "";
            List<PieEntry> pieList = new ArrayList<>();
            URL url = null;
            HttpURLConnection conn = null;
            final String methodPath = "assign1.memoir/task4_a_numberOfMoviesWatchedPerPostcode/";
            try {
                url = new URL(LoginActivity.BASE_URL + methodPath+LoginActivity.uid+"/"+strings[0]+"/"+strings[1]);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            try {
                JSONArray jsonArray = new JSONArray(textResult);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                    PieEntry pie = new PieEntry(Integer.parseInt(jsonObject.getString("numberOfMovies")),jsonObject.getString("cinemaPostCode"));
                    pieList.add(pie);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return pieList;
        }

        @Override
        protected void onPostExecute(List<PieEntry> pieEntryList) {
            pieChart.setUsePercentValues(true);
            pieChart.getDescription().setText("Number of watched movie per postcode");
            pieChart.setExtraOffsets(5, 10, 5, 5);
            ArrayList<Integer> colors = new ArrayList<Integer>();
            for (int c : ColorTemplate.MATERIAL_COLORS)
                colors.add(c);
            for (int c : ColorTemplate.JOYFUL_COLORS)
                colors.add(c);
            for (int c : ColorTemplate.COLORFUL_COLORS)
                colors.add(c);
            colors.add(ColorTemplate.getHoloBlue());
            PieDataSet pieDataSet = new PieDataSet(pieEntryList, "Postcode");

            pieDataSet.setColors(colors);
            PieData pie = new PieData();
            pie.setValueFormatter(new PercentFormatter());
            pie.setDataSet(pieDataSet);

            pieChart.setData(pie);
           // pieChart.setUsePercentValues(true);
            pieChart.invalidate();
        }
    }

    //assign1.memoir/task4_b_numberOfMoviesWatchedPerMonth/{personId}/{year}
    private class numberOfMoviesWatchedPerMonth extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {
            xValueList = new ArrayList<>();
            yValueList = new ArrayList<>();
            barDataSets = new ArrayList<>();
            dataLinkedHashmap = new LinkedHashMap<>();
            String textResult = "";
            URL url = null;
            HttpURLConnection conn = null;
            final String methodPath = "assign1.memoir/task4_b_numberOfMoviesWatchedPerMonth/";
            try {
                url = new URL(LoginActivity.BASE_URL + methodPath + LoginActivity.uid + "/" + strings[0]);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            try {
                JSONArray jsonArray = new JSONArray(textResult);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                    xValueList.add(jsonObject.getString("WatchMonth"));
                    yValueList.add(Integer.parseInt(jsonObject.getString("numberOfMovies")));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            dataLinkedHashmap.put("Month", yValueList);
            ArrayList<Integer> colors = new ArrayList<Integer>();
            for (int c : ColorTemplate.MATERIAL_COLORS)
                colors.add(c);
            for (int c : ColorTemplate.JOYFUL_COLORS)
                colors.add(c);
            colors.add(ColorTemplate.getHoloBlue());
            int positionCurrent = 0;
            for (LinkedHashMap.Entry<String, List<Integer>> entry : dataLinkedHashmap.entrySet()) {
                String name = entry.getKey();
                List<Integer> yValueList = entry.getValue();
                List<BarEntry> entries = new ArrayList<>();

                for (int i = 0; i < yValueList.size(); i++) {
                    entries.add(new BarEntry(i, yValueList.get(i)));
                }
                BarDataSet barDataSet = new BarDataSet(entries, name);
                initBarDataSet(barDataSet, colors.get(positionCurrent));
                barDataSets.add(barDataSet);
                positionCurrent++;

            }
            return textResult;
        }
        @Override
        protected void onPostExecute(String data) {
            BarData barData = new BarData(barDataSets);
            barData.setBarWidth(0.5f);
            int barAmount = dataLinkedHashmap.size();
            float groupSpace = 0.3f;
            float barWidth = (1f - groupSpace) / barAmount;
            float barSpace = 0f;
            barData.setBarWidth(barWidth);
            barChart.setBackgroundColor(Color.WHITE);
            barChart.setDrawGridBackground(false);
            barChart.setDrawBarShadow(false);
            barChart.setHighlightFullBarEnabled(false);
            barChart.setDrawBorders(true);
            barChart.setData(barData);
            XAxis xAxis = barChart.getXAxis();
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            xAxis.setAxisMinimum(0f);
            xAxis.setGranularity(1f);
            xAxis.setDrawGridLines(false);
            xAxis.setAxisMinimum(0f);
            xAxis.setAxisMaximum(xValueList.size());
            xAxis.setCenterAxisLabels(false);
            YAxis leftAxis = barChart.getAxisLeft();
            YAxis rightAxis = barChart.getAxisRight();
            leftAxis.setAxisMinimum(0f);
            rightAxis.setAxisMinimum(0f);

            Legend legend = barChart.getLegend();
            legend.setForm(Legend.LegendForm.LINE);
            legend.setTextSize(11f);

            legend.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
            legend.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
            legend.setOrientation(Legend.LegendOrientation.HORIZONTAL);

            legend.setDrawInside(false);
            xAxis.setValueFormatter(new IAxisValueFormatter() {
                @Override
                public String getFormattedValue(float value, AxisBase axis) {
                    return xValueList.get((int) Math.abs(value) % xValueList.size());
                }
            });
        }
    }
    private void initBarDataSet(BarDataSet barDataSet, int color) {
        barDataSet.setColor(color);
        barDataSet.setFormLineWidth(1f);
        barDataSet.setFormSize(15.f);
        barDataSet.setDrawValues(false);
    }
}
