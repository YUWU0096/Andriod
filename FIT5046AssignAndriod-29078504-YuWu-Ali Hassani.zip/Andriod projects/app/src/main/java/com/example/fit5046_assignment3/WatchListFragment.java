package com.example.fit5046_assignment3;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Observer;

import com.example.fit5046_assignment3.database.WatchList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class WatchListFragment extends Fragment {
    View watchListView;
    private ListView listView_watchlist;
    private List<HashMap<String,String>> listArrayWatchlist = new ArrayList<HashMap<String,String>>();
    private String movieID;
    private String watchID;
    private TextView text_movieSelected;
    private Button button_viewMovie;
    private Button button_deleteMovie;

    private String movieName;


    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        watchListView = inflater.inflate(R.layout.fragment_watchlist, container, false);
        listView_watchlist = watchListView.findViewById(R.id.listView_watchlist);
        text_movieSelected = watchListView.findViewById(R.id.text_watchlist_movieSelected);
        button_viewMovie = watchListView.findViewById(R.id.button_watchlist_viewMovie);
        button_deleteMovie= watchListView.findViewById(R.id.button_watchlist_deleteMovie);

        MenuFragment.watchListViewModel.getAllWatchLists(LoginActivity.uid.toString()).observe(getViewLifecycleOwner(), new Observer<List<WatchList>>() {
            @Override
            public void onChanged(List<WatchList> watchLists) {
                listArrayWatchlist.clear();
                for(WatchList watchList : watchLists){
                    HashMap<String,String> hashMap = new HashMap<>();
                    hashMap.put("Watch ID", String.valueOf(watchList.getWatchID()));
                    hashMap.put("Movie Name", watchList.getMovieName());
                    hashMap.put("Movie ID",watchList.getMovieID());
                    hashMap.put("Released Date",watchList.getReleaseDate());
                    hashMap.put("Date to added", watchList.getDateAdded());
                    hashMap.put("Time to added", watchList.getTimeAdded());
                    listArrayWatchlist.add(hashMap);
                }
                String[] header = new String[]{"Movie Name","Released Date","Date to added","Time to added","Movie ID","Watch ID"};
                int[] value = new int[]{R.id.text_listview_watchlist_moviename,R.id.text_listview_watchlist_releasedate,R.id.text_listview_watchlist_dateAdded,
                       R.id.text_listview_watchlist_timeAdded,R.id.text_listview_watchlist_movieID,R.id.text_listview_watchlist_watchID};
                SimpleAdapter simpleAdapter = new SimpleAdapter(WatchListFragment.this.getActivity(),listArrayWatchlist,R.layout.movie_listview_watchlist,header,value);
                listView_watchlist.setAdapter(simpleAdapter);
            }
        });

        listView_watchlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                movieID = listArrayWatchlist.get(position).get("Movie ID");
                watchID = listArrayWatchlist.get(position).get("Watch ID");
                movieName = listArrayWatchlist.get(position).get("Movie Name");
                text_movieSelected.setText(" You selected " + movieName);
                text_movieSelected.setVisibility(View.VISIBLE);
                button_deleteMovie.setVisibility(View.VISIBLE);
                button_viewMovie.setVisibility(View.VISIBLE);
            }
        });
        button_viewMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Fragment fragment = new MovieViewFragment();
                Bundle bundle = new Bundle();
                bundle.putString("movieId", movieID);
                bundle.putString("movieName",movieName);
                bundle.putString("flag","false");
                fragment.setArguments(bundle);
                FragmentManager fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame,fragment).commit();


            }
        });
        button_deleteMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(WatchListFragment.this.getActivity());
                alert.setTitle("Do you want to delete this movie?");
                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MenuFragment.watchListViewModel.deleteByWatchID(Integer.parseInt(watchID));
                        text_movieSelected.setVisibility(View.INVISIBLE);
                        Toast.makeText(watchListView.getContext(),"The movie is deleted!",Toast.LENGTH_SHORT).show();
                    }
                });
                alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alert.show();
            }
        });
        button_viewMovie.setVisibility(View.INVISIBLE);
        button_deleteMovie.setVisibility(View.INVISIBLE);
        text_movieSelected.setVisibility(View.INVISIBLE);
        return watchListView;
    }

}
