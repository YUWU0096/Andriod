package com.example.fit5046_assignment3;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.example.fit5046_assignment3.Class.Cinema;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AddCinemaFragment extends Fragment {
private View addCinemaView;
private EditText addCinemaName;
private EditText addPostCode;
private Integer cinemaID;
private Cinema cinema;
private List<String> movieList = new ArrayList<>();
private String movieName;
private String movieID;
private String releaseDate;
private String ImageURL;
private Button button_addCinema;
private List<String> allCinemaNames = new ArrayList<>();


public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
    addCinemaView = inflater.inflate(R.layout.movie_addcinema, container, false);
    addCinemaName = addCinemaView.findViewById(R.id.edit_addcinema_cinemaName);
    addPostCode = addCinemaView.findViewById(R.id.edit_addcinema_postcode);
    button_addCinema = addCinemaView.findViewById(R.id.button_addCinema);

    new AsyncGetCinemaName().execute();
    if(getArguments()!=null){
        movieID  = getArguments().getString("movieId");
        movieName = getArguments().getString("movieName");
        releaseDate = getArguments().getString("releaseDate");
        ImageURL = getArguments().getString("imageURL");
        movieList.add(movieID);
        movieList.add(movieName);
        movieList.add(ImageURL);
        movieList.add(releaseDate);

    }

    button_addCinema.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            boolean flag = true;
            String newCinemanameGet = addCinemaName.getText().toString();
            for (String i : allCinemaNames) {
                if (newCinemanameGet.equals(i)) {
                    flag = false;
                   addCinemaName.setError("Sorry, the Cinema is existed");
                }
            }

            if (addCinemaName.getText().toString().isEmpty()||addPostCode.getText().toString().isEmpty()){
                Toast.makeText(addCinemaView.getContext(),"Please enter all cinema information",Toast.LENGTH_SHORT).show();;
            }
            else {
                if (flag == true)
                {
                cinema = new Cinema();
                cinema.setCinemaPostcode(addPostCode.getText().toString());
                cinema.setCinemaName(addCinemaName.getText().toString());
                new getCinemaID().execute();}
                else {
                    Toast.makeText(addCinemaView.getContext(), "Please check your information again", Toast.LENGTH_SHORT).show();
                }

            }
        }
    });

return addCinemaView;

}

 private class getCinemaID extends AsyncTask<Cinema, Void, Integer> {
        @Override
        protected Integer doInBackground(Cinema... cinemas) {
            String textResult = " ";
            URL url = null;
            HttpURLConnection conn = null;
            final String methodPath = "assign1.cinema/getNewCinemaID";
            try {
                url = new URL(LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }

            try {
                JSONObject jsonObject = new JSONObject(textResult);
                String getCinemaID = jsonObject.getString("cinemaId");
                cinemaID = Integer.valueOf(getCinemaID) + 1;
                cinema.setCinemaId(cinemaID);
                new AsyncPostCinema().execute(cinema);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return cinemaID;
        }
    }
    private class AsyncPostCinema extends AsyncTask<Cinema, Void, Cinema> {
        @Override

        protected Cinema doInBackground(Cinema... cinemas) {
            URL url = null;
            HttpURLConnection conn = null;
            String textResult = "";
            final String methodPath = "assign1.cinema/";
            try {
                Gson gson = new Gson();
                String stringJson = gson.toJson(cinemas[0]);
                String replaceJson = stringJson.replace("[", "").replace("]", "");
                url = new URL(LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setFixedLengthStreamingMode(replaceJson.getBytes().length);
                conn.setRequestProperty("Content-Type", "application/json");
                PrintWriter writer = new PrintWriter(conn.getOutputStream());
                writer.print(replaceJson);
                writer.flush();
                writer.close();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            return cinemas[0];
        }
        @Override
        protected void onPostExecute(Cinema cinema) {
            super.onPostExecute(cinema);
            Toast.makeText(addCinemaView.getContext(),"The cinema is added!!!!",Toast.LENGTH_SHORT).show();
            Fragment fragment = new AddMemoirFragment();
            Bundle bundle = new Bundle();
            bundle.putString("movieId",movieList.get(0));
            bundle.putString("movieName",movieList.get(1));
            bundle.putString("imageURL",movieList.get(2));
            bundle.putString("releaseDate",movieList.get(3));
            fragment.setArguments(bundle);
            FragmentManager fragmentManager = getFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.content_frame,fragment).commit();
        }
    }

    private class AsyncGetCinemaName extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            URL url = null;
            HttpURLConnection conn = null;
            String textResult = "";
            final String methodPath = "assign1.cinema/getAllCinemaname";
            try {
                url = new URL(LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            try {
                JSONArray jsonArray = new JSONArray(textResult);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                    String getCinemaname = jsonObject.getString("cinemaname");
                    allCinemaNames.add(getCinemaname);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return textResult;
        }
    }

}
