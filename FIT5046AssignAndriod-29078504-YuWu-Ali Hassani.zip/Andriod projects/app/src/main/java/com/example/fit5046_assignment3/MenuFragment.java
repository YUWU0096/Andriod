package com.example.fit5046_assignment3;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.fit5046_assignment3.database.WatchListViewModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class MenuFragment extends Fragment {

    private View menuView;
    private ListView movieListView;
    private List<HashMap<String,String>> listArray = new ArrayList<HashMap<String,String>>();
    public static WatchListViewModel watchListViewModel;
    private SharedPreferences sp;
    @SuppressLint("SetTextI18n")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle
            savedInstanceState) {
        menuView = inflater.inflate(R.layout.fragment_main, container, false);
        TextView text_welcome = (TextView)  menuView.findViewById(R.id.text_welcome);

        sp = getActivity().getSharedPreferences(String.valueOf(LoginActivity.uid), Context.MODE_PRIVATE);
        String fname = sp.getString("firstName","");
        text_welcome.setText("Welcome "+ fname+ "！");
        //Current date
        TextView text_currentDate = (TextView) menuView.findViewById(R.id.currentDate);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
        Date date = new Date(System.currentTimeMillis());
        text_currentDate.setText("Today is "+simpleDateFormat.format(date));

        new AsyncGetTop5Movie().execute();
        //
        movieListView = menuView.findViewById(R.id.listView);
        //
        watchListViewModel = new ViewModelProvider(this).get(WatchListViewModel.class);
        watchListViewModel.initalizeVars(getActivity().getApplication());
        return menuView;
    }



    private class AsyncGetTop5Movie extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... strings) {
            URL url = null;
            HttpURLConnection connection = null;
            String textResult = "";
            final String methodPath = "assign1.memoir/task4_f_top5MovieInRecenYear";
            try {
                url = new URL (LoginActivity.BASE_URL + methodPath + "/"+ LoginActivity.uid);
                connection = (HttpURLConnection) url.openConnection();
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);
                connection.setRequestMethod("GET");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(connection.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                connection.disconnect();
            }

            return textResult;
        }

        @Override
        protected void onPostExecute (String textResult){
            super.onPostExecute(textResult);
            JSONArray jsonArray = null;
            try{
                jsonArray = new JSONArray(textResult);
            for(int j = 0; j< jsonArray.length();j++){
                JSONObject jsonObject = (JSONObject) jsonArray.get(j);
                HashMap<String,String> hashMap = new HashMap<String, String>();
                hashMap.put("Movie Name", jsonObject.getString("MovieName"));
                hashMap.put("Release Date", jsonObject.getString("ReleaseDate"));
                hashMap.put("Rating Score", jsonObject.getString("RatingScore"));
                listArray.add(hashMap);
            }}catch (JSONException e){
                e.printStackTrace();
            }
            String[] header = new String[]{"Movie Name","Release Date","Rating Score"};
            int[] value = new int[]{R.id.text_moviename_list,R.id.text_releaseDate_list,R.id.text_ratingScore_list};
            SimpleAdapter listViewAdapter = new SimpleAdapter(MenuFragment.this.getActivity(),listArray,R.layout.movie_listview,header,value);
            movieListView.setAdapter(listViewAdapter);
        }
}
}
