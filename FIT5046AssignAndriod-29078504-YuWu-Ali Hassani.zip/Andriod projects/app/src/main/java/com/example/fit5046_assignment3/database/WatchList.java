package com.example.fit5046_assignment3.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class WatchList {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name= "watchID")
    private int watchID;

    @ColumnInfo(name= "movieName")
    private String movieName;
    @ColumnInfo(name="releaseDate")
    private String releaseDate;
    @ColumnInfo(name="dateAdded")
    private String dateAdded;
    @ColumnInfo(name = "timeAdded")
    private String timeAdded;
    @ColumnInfo(name = "personID")
    private String personID;
    @ColumnInfo(name = "movieID")
    private String movieID;

    public int getWatchID() {
        return watchID;
    }

    public void setWatchID(int watchID) {
        this.watchID = watchID;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(String dateAdded) {
        this.dateAdded = dateAdded;
    }

    public String getTimeAdded() {
        return timeAdded;
    }

    public void setTimeAdded(String timeAdded) {
        this.timeAdded = timeAdded;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getMovieID() {
        return movieID;
    }

    public void setMovieID(String movieID) {
        this.movieID = movieID;
    }




}
