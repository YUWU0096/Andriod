package com.example.fit5046_assignment3;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class SearchAddressAPI {
    private static final String apiKey = "AIzaSyBEd6JryP14-c15eLppKVJ1tTKAxVZGnt8";

    public static String searchAddress(String address){
        URL url = null;
        HttpURLConnection connection = null;
        String textResult = "";
        try{
            url = new URL("https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input="+address+
                            "&inputtype=textquery&fields=name,geometry&key="+apiKey);
            connection = (HttpURLConnection) url.openConnection();
            connection.setReadTimeout(10000);
            connection.setConnectTimeout(15000);
            connection.setRequestMethod("GET");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            Scanner inStream = new Scanner(connection.getInputStream());
            while (inStream.hasNextLine()) {
                textResult += inStream.nextLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            connection.disconnect();
        }
        return textResult;
    }

    public static String searchCinemaAddress(List<String> address){

        for (String i:address){
            URL url = null;
            HttpURLConnection connection = null;
            String textResult = "";
            try{
                url = new URL("https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input="+i+
                        "&inputtype=textquery&fields=name,geometry&key="+apiKey);
                connection = (HttpURLConnection) url.openConnection();
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);
                connection.setRequestMethod("GET");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(connection.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }finally {
                connection.disconnect();
            }

            try{
                JSONObject jsonObject = new JSONObject(textResult);
                String candidateString = jsonObject.getString("candidates");
                JSONArray candidateArray = new JSONArray(candidateString);
                JSONObject jsonObject1 = (JSONObject) candidateArray.get(0);

                String geometry = jsonObject1.getString("geometry");
                JSONObject jsonObject2 = new JSONObject(geometry);
                String location =jsonObject2.getString("location");
                JSONObject jsonObject3 = new JSONObject(location);
               HashMap<String,String> hashMap = new HashMap<>();
               hashMap.put("lat",jsonObject3.getString("lat"));
               hashMap.put("lng",jsonObject3.getString("lng"));
               LoginActivity.cinemaLocation.add(hashMap);
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }


    return  null;

    }
}
