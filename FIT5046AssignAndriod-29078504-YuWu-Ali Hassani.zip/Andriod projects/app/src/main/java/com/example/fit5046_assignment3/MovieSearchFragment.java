package com.example.fit5046_assignment3;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MovieSearchFragment extends Fragment {
    private View movieSearchView;
    private Button button_movieSearch;
    private EditText text_movieSearch;
    private String searchText;
    private List<String> listReturn = new ArrayList<String>();
    private ListView movieListView;
    private List<HashMap<String,?>> listArraySearch = new ArrayList<>();


    @Override
    public View onCreateView( LayoutInflater inflater,  ViewGroup container,  Bundle savedInstanceState) {
        movieSearchView = inflater.inflate(R.layout.fragment_movie_search,container,false);
        button_movieSearch =(Button) movieSearchView.findViewById(R.id.button_search);
        text_movieSearch = (EditText) movieSearchView.findViewById(R.id.text_search);
        movieListView =(ListView) movieSearchView.findViewById(R.id.movielist_search);
        button_movieSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchText = text_movieSearch.getText().toString();
                new AsyncSearchMovie().execute(searchText);
            }
        });
        return movieSearchView;
    }

    private class AsyncSearchMovie extends AsyncTask<String,Void,String>{
        @Override
        protected String doInBackground(String... strings) {
            return SearchMovieAPI.searchMovie(strings[0]);
        }

        protected void onPostExecute(String result) {
            if(result.isEmpty()){  Toast.makeText(movieSearchView.getContext(),"The movie cannot be null!",Toast.LENGTH_SHORT).show();}
            else {
                new AsyncGetMovieList().execute(result);
            }
           }

    }

    private class AsyncGetMovieList extends AsyncTask<String,Void, SimpleAdapter>{

        @Override
        protected SimpleAdapter doInBackground(String... strings) {
            listArraySearch.clear();
            listReturn = SearchMovieAPI.getSnippet(strings[0]);
            for(int j =0; j<listReturn.size();j+=4){


                   HashMap<String,Object> hashMap = new HashMap<String, Object>();
                   hashMap.put("Movie Name",listReturn.get(j));
                   hashMap.put("Release Date",listReturn.get(j+1));
                   hashMap.put("MovieID",listReturn.get(j+3));
                   String imageURL = "https://image.tmdb.org/t/p/w600_and_h900_bestv2"+listReturn.get(j+2);
                   Bitmap bitmap;
                   try{
                       URL url = new URL(imageURL);
                       InputStream inputStream = url.openStream();
                       bitmap = BitmapFactory.decodeStream(inputStream);
                       inputStream.close();
                       hashMap.put("MovieImage",bitmap);
                   } catch (IOException e) {
                       e.printStackTrace();
                   }
                   listArraySearch.add(hashMap);
            }
            String[] header = new String[]{"Movie Name","Release Date","MovieImage","MovieID"};
            int[] value = new int[]{R.id.text_moviename_list_search,R.id.text_releaseDate_list_search,R.id.text_MoveiImage_list_search,R.id.text_movieID_list_search};
            SimpleAdapter listViewAdapter = new SimpleAdapter(MovieSearchFragment.this.getActivity(),listArraySearch,R.layout.movie_listview_search,header,value);

            listViewAdapter.setViewBinder(new SimpleAdapter.ViewBinder() {
                @Override
                public boolean setViewValue(View view, Object data, String textRepresentation) {
                    if((view instanceof ImageView)&(data instanceof Bitmap)){
                        ImageView imageView=(ImageView) view;
                        Bitmap bitmap = (Bitmap) data;
                        imageView.setImageBitmap(bitmap);
                        return true;
                    }
                    return false;
                }
            });
            return listViewAdapter;
        }
        @Override
        protected void onPostExecute(SimpleAdapter simpleAdapter){
        movieListView.setAdapter(simpleAdapter);
        movieListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String ID = listArraySearch.get(position).get("MovieID").toString();
                String movieName = listArraySearch.get(position).get("Movie Name").toString();

                Fragment fragment=new MovieViewFragment();
                Bundle bundle = new Bundle();
                bundle.putString("movieId",ID);
                bundle.putString("movieName",movieName);
                bundle.putString("flag","true");
                fragment.setArguments(bundle);
                FragmentManager fragmentManager = getFragmentManager();
                fragmentManager.beginTransaction().replace(R.id.content_frame,fragment).commit();
            }
        });
        }
    }
}

