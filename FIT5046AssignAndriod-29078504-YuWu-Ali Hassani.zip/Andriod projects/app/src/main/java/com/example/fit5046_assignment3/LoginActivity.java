package com.example.fit5046_assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.fit5046_assignment3.Class.Credentials;
import com.example.fit5046_assignment3.Class.Person;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class LoginActivity extends AppCompatActivity {
    private static final String TAG = "LoginActivity";
    private EditText enterUsername;
    private EditText enterPassword;
    public static final String BASE_URL = "http://192.168.3.12:8080/Assignment1/webresources/";
    private Integer credentialID = 0;
    public static Integer uid;
    public static Person personData;
    private Credentials credentials;
    private SharedPreferences sp;
    private String address;
    public static String latitude;
    public static String longitude;
    public static List<String> allCinemaNameList;
    public static List<HashMap<String,String>> cinemaLocation = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Button login = (Button) findViewById(R.id.login_button);
        Button signup = (Button) findViewById(R.id.signup_button);
        enterUsername = (EditText) findViewById(R.id.et_UserName);
        enterPassword = (EditText) findViewById(R.id.et_PassWord);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(enterUsername.getText().toString().isEmpty() ||enterPassword.getText().toString().isEmpty() )
                {
                  Toast.makeText(LoginActivity.this,"The username or password cannot be null!", Toast.LENGTH_SHORT).show();
                }
                else{
                    new getLogin().execute(enterUsername.getText().toString(), enterPassword.getText().toString());

                }

            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });
    }

    private class getLogin extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {

            String username = strings[0];
            String password = strings[1];
            URL url = null;
            HttpURLConnection conn = null;
            String textResult = "";
            final String methodPath = "assign1.credentials/getPasswordAndUserName/";
            try {

                url = new URL (BASE_URL + methodPath + username + "/" + getSHA256StrJava(password));
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }


            return textResult;
        }

        protected void onPostExecute(String textResult) {
            super.onPostExecute(textResult);
            try{
                JSONArray jsonArray = new JSONArray(textResult);
                for (int i = 0; i<jsonArray.length();i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    credentialID = Integer.parseInt(jsonObject.getString("credentialId"));
                    uid = credentialID;
                }
                /*String replaceText = textResult.replace("[","").replace("]","");
                JSONObject jsonObject = new JSONObject(replaceText);*/

            }catch (JSONException e) {
                e.printStackTrace();
            }
            if (textResult.equals("[]")) {
                Toast.makeText(LoginActivity.this, "Wrong username or password! Please enter again", Toast.LENGTH_SHORT).show();
            } else {
                new AsyncGetUserNameNow().execute(credentialID);
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
            }

        }

        private String getSHA256StrJava(String str) {
            MessageDigest messageDigest;
            String encodeStr = "";
            try {
                messageDigest = MessageDigest.getInstance("SHA-256");
                messageDigest.update(str.getBytes("UTF-8"));
                encodeStr = byte2Hex(messageDigest.digest());
            }catch (NoSuchAlgorithmException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            return encodeStr;
        }
        private String byte2Hex(byte[] bytes) {
            StringBuilder stringBuffer = new StringBuilder();
            String temp = null;
            for (int i = 0; i < bytes.length; i++) {
                temp = Integer.toHexString(bytes[i] & 0xFF);
                if (temp.length() == 1) {
                    stringBuffer.append("0");
                }
                stringBuffer.append(temp);
            }
            return stringBuffer.toString();
        }
    }


    private class AsyncGetUserNameNow extends AsyncTask<Integer, Void, String> {
        @Override
        protected String doInBackground(Integer... integers) {
            URL url = null;
            HttpURLConnection conn = null;
            String textResult = "";
            Integer credentialId = integers[0];
            final String methodPath = "assign1.person/task3_a_findByCredentialId/";
            try {
                url = new URL (LoginActivity.BASE_URL + methodPath+ credentialId);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            return textResult;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {
                String replaceText = s.replace("[","").replace("]","");
                JSONObject jsonObject = new JSONObject(replaceText);
                String firstName = jsonObject.getString("firstName");
                String personID = jsonObject.getString("personId");

                credentials = new Credentials();
                JSONObject credentialObject = jsonObject.getJSONObject("credentialId");
                credentials.setCredentialId(Integer.valueOf(personID));
                credentials.setPasswordHash(credentialObject.getString("passwordHash"));
                credentials.setUsername(credentialObject.getString("username"));
                credentials.setSignupDate(credentialObject.getString("signupDate"));

                personData = new Person();
                personData.setFirstName(jsonObject.getString("firstName"));
                personData.setSurname(jsonObject.getString("surname"));
                personData.setPersonId(Integer.valueOf(personID));
                personData.setCredentialId(credentials);
                personData.setAddress(jsonObject.getString("address"));
                personData.setDob(jsonObject.getString("dob"));
                String genderString = jsonObject.getString("gender");
                Character gender = genderString.charAt(0);
                personData.setGender(gender);
                personData.setPostcode(jsonObject.getString("postcode"));
                personData.setState(jsonObject.getString("state"));
                address = jsonObject.getString("address");
                new SearchUserADDRESS().execute(address);
                sp = LoginActivity.this.getSharedPreferences(personID, MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("firstName", firstName);
                editor.commit();
            } catch (JSONException ex) {
                ex.printStackTrace();
            }
        }
    }

    private class SearchUserADDRESS extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... strings) {

            return SearchAddressAPI.searchAddress(strings[0]);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try{
                JSONObject jsonObject = new JSONObject(s);
                String candidateString = jsonObject.getString("candidates");
                JSONArray candidateArray = new JSONArray(candidateString);
                JSONObject jsonObject1 = (JSONObject) candidateArray.get(0);

                String geometry = jsonObject1.getString("geometry");
               JSONObject jsonObject2 = new JSONObject(geometry);
               String location =jsonObject2.getString("location");
               JSONObject jsonObject3 = new JSONObject(location);
               latitude = jsonObject3.getString("lat");
               longitude = jsonObject3.getString("lng");
               new AsyncGetCinemaName().execute();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class AsyncGetCinemaName extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            URL url = null;
            HttpURLConnection conn = null;
            String textResult = "";
            final String methodPath = "assign1.cinema/getAllCinemaname";
            try {
                url = new URL(LoginActivity.BASE_URL + methodPath);
                conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(10000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setRequestProperty("Accept", "application/json");
                Scanner inStream = new Scanner(conn.getInputStream());
                while (inStream.hasNextLine()) {
                    textResult += inStream.nextLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                conn.disconnect();
            }
            try {
                JSONArray jsonArray = new JSONArray(textResult);
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                    String getCinemaname = jsonObject.getString("cinemaname");
                    allCinemaNameList.add(getCinemaname);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            new searchCinemaList().execute();
            return textResult;
        }
    }

    private class searchCinemaList  extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... strings) {
            return SearchAddressAPI.searchCinemaAddress(allCinemaNameList);
        }
    }
}
