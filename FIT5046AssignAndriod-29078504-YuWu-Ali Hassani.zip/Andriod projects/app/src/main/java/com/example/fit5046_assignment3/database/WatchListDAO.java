package com.example.fit5046_assignment3.database;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import static androidx.room.OnConflictStrategy.REPLACE;
import java.util.List;

@Dao
public interface WatchListDAO {
    @Query("SELECT * FROM WatchList")
    List<WatchList> getAll();
    @Query("SELECT * FROM WatchList WHERE watchID = :watchId LIMIT 1")
    WatchList findByID(int watchId);
    @Insert
    void insertAll(WatchList... watchLists);
    @Insert
    long insert(WatchList watchLists);
    @Delete
    void delete(WatchList watchLists);
    @Update(onConflict = REPLACE)
    void updateWatchList(WatchList... watchLists);
    @Query("DELETE FROM WatchList")
    void deleteAll();

    @Query("SELECT * FROM WatchList where personID = :personID")
    LiveData<List<WatchList>> findByPersonID(String personID);

    @Query("SELECT * FROM WatchList where personID = :personID")
    List<WatchList> findByPersonIDList(String personID);

    @Query(("Delete FROM WatchList where watchID = :watchID"))
    void deleteByWatchID(int watchID);

}
