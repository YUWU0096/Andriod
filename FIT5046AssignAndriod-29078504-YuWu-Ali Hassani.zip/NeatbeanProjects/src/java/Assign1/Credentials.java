/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Assign1;

import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author wuyu327
 */
@Entity
@Table(name = "CREDENTIALS")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Credentials.findAll", query = "SELECT c FROM Credentials c")
    , @NamedQuery(name = "Credentials.findByCredentialId", query = "SELECT c FROM Credentials c WHERE c.credentialId = :credentialId")
    , @NamedQuery(name = "Credentials.findByUsername", query = "SELECT c FROM Credentials c WHERE c.username = :username")
    , @NamedQuery(name = "Credentials.findByPasswordHash", query = "SELECT c FROM Credentials c WHERE c.passwordHash = :passwordHash")
    , @NamedQuery(name = "Credentials.findBySignupDate", query = "SELECT c FROM Credentials c WHERE c.signupDate = :signupDate")
    , @NamedQuery(name = "Credentials.task3_a_findByUsername", query = "SELECT c FROM Credentials c WHERE c.username = :username")
    , @NamedQuery(name = "Credentials.task3_a_findByPasswordHash", query = "SELECT c FROM Credentials c WHERE c.passwordHash = :passwordHash")  
    , @NamedQuery(name = "Credentials.task3_a_findBySignupDate", query = "SELECT c FROM Credentials c WHERE c.signupDate = :signupDate") 
    ,@NamedQuery(name = "Credentials.getPasswordAndUserName", query = "SELECT c FROM Credentials c WHERE c.username = :username AND c.passwordHash = :passwordHash")
    , @NamedQuery(name = "Credentials.getLastCredentialsID", query = "SELECT c FROM Credentials c order by c.credentialId desc") 
})
public class Credentials implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "CREDENTIAL_ID")
    private Integer credentialId;
    @Size(max = 60)
    @Column(name = "USERNAME")
    private String username;
    @Size(max = 255)
    @Column(name = "PASSWORD_HASH")
    private String passwordHash;
    @Column(name = "SIGNUP_DATE")
    @Temporal(TemporalType.DATE)
    private Date signupDate;
    @OneToMany(mappedBy = "credentialId")
    private Collection<Person> personCollection;

    public Credentials() {
    }

    public Credentials(Integer credentialId) {
        this.credentialId = credentialId;
    }

    public Integer getCredentialId() {
        return credentialId;
    }

    public void setCredentialId(Integer credentialId) {
        this.credentialId = credentialId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public Date getSignupDate() {
        return signupDate;
    }

    public void setSignupDate(Date signupDate) {
        this.signupDate = signupDate;
    }

    @XmlTransient
    public Collection<Person> getPersonCollection() {
        return personCollection;
    }

    public void setPersonCollection(Collection<Person> personCollection) {
        this.personCollection = personCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (credentialId != null ? credentialId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Credentials)) {
            return false;
        }
        Credentials other = (Credentials) object;
        if ((this.credentialId == null && other.credentialId != null) || (this.credentialId != null && !this.credentialId.equals(other.credentialId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Assign1.Credentials[ credentialId=" + credentialId + " ]";
    }
    
}
