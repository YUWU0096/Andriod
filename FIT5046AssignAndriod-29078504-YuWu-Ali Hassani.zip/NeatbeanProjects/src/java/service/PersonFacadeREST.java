/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;


import Assign1.Person;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author wuyu327
 */
@Stateless
@Path("assign1.person")
public class PersonFacadeREST extends AbstractFacade<Person> {

    @PersistenceContext(unitName = "Assignment1PU")
    private EntityManager em;

    public PersonFacadeREST() {
        super(Person.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Person entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Person entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Person find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @GET
    @Path("task3_a_findByFirstName/{firstName}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> task3_a_findByFirstName(@PathParam("firstName") String firstName){
        Query query = em.createNamedQuery("Person.task3_a_findByFirstName");
        query.setParameter("firstName",firstName);
        return query.getResultList();
    }
    
    @GET
    @Path("task3_a_findBySurname/{surname}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> task3_a_findBySurname(@PathParam("surname") String surname){
        Query query = em.createNamedQuery("Person.task3_a_findBySurname");
        query.setParameter("surname",surname);
        return query.getResultList();
    }
    
    @GET
    @Path("task3_a_findByGender/{gender}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> task3_a_findByGender(@PathParam("gender") String gender){
        Query query = em.createNamedQuery("Person.task3_a_findByGender");
        char charAt = gender.charAt(0);
        query.setParameter("gender",charAt);
        return query.getResultList();
    }
    
    @GET
    @Path("task3_a_findByDoB/{dob}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> task3_a_findByDoB(@PathParam("dob") String dob) throws ParseException{
        Query query = em.createNamedQuery("Person.task3_a_findByDoB");
        DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        Date date = fmt.parse(dob);
        query.setParameter("dob",date);
        return query.getResultList();
    }
    
    @GET
    @Path("task3_a_findByAddress/{address}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> task3_a_findByAddress(@PathParam("address") String address){
        Query query = em.createNamedQuery("Person.task3_a_findByAddress");
        query.setParameter("address",address);
        return query.getResultList();
    }
    
    @GET
    @Path("task3_a_findByState/{state}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> task3_a_findByState(@PathParam("state") String state){
        Query query = em.createNamedQuery("Person.task3_a_findByState");
        query.setParameter("state",state);
        return query.getResultList();
    }
    
    @GET
    @Path("task3_a_findByPostcode/{postcode}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> task3_a_findByPostcode(@PathParam("postcode") String postcode){
        Query query = em.createNamedQuery("Person.task3_a_findByPostcode");
        query.setParameter("postcode",postcode);
        return query.getResultList();
    }
    
    @GET
    @Path("task3_a_findByCredentialId/{credentialId}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Person> task3_a_findByCredentialId(@PathParam("credentialId") Integer credentialId){
        Query query = em.createNamedQuery("Person.task3_a_findByCredentialId");
        query.setParameter("credentialId",credentialId);
        return query.getResultList();
    }

    @GET
    @Path("task3_b_combinationOfThreeAttributes/{address}/{state}/{postcode}")
    @Produces({MediaType.APPLICATION_JSON})
    public List<Person> task3_b_combinationOfThreeAttributes(
            @PathParam("address") String address,
            @PathParam("state") String state,
            @PathParam("postcode") String postcode) 
    {
        TypedQuery<Person> query = em.createQuery(
        "SELECT p FROM Person p WHERE p.address = :address and p.state = :state and p.postcode = :postcode",
       Person.class);
        query.setParameter("address",address);
        query.setParameter("state",state);
        query.setParameter("postcode",postcode);
    return query.getResultList();
    }
    
 
   
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
