/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import Assign1.Cinema;
import java.util.List;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author wuyu327
 */
@Stateless
@Path("assign1.cinema")
public class CinemaFacadeREST extends AbstractFacade<Cinema> {

    @PersistenceContext(unitName = "Assignment1PU")
    private EntityManager em;

    public CinemaFacadeREST() {
        super(Cinema.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Cinema entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Cinema entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Cinema find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Cinema> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Cinema> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }
    
    @GET
    @Path("task3_a_findByCinemaName/{cinemaName}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Cinema> task3_a_findByCinemaName(@PathParam("cinemaName") String cinemaName){
        Query query = em.createNamedQuery("Cinema.task3_a_findByCinemaName");
        query.setParameter("cinemaName",cinemaName);
        return query.getResultList();
    }
    
     @GET
    @Path("task3_a_findByCinemaPostcode/{cinemaPostcode}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Cinema> task3_a_findByCinemaPostcode(@PathParam("cinemaName") String cinemaPostcode){
        Query query = em.createNamedQuery("Cinema.task3_a_findByCinemaPostcode");
        query.setParameter("cinemaPostcode",cinemaPostcode);
        return query.getResultList();
    }
    
    @GET
    @Path("getLastCinemaID")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Cinema> getLastCinemaID(){
        Query query = em.createNamedQuery("Cinema.getLastCinemaID");
        return query.getResultList();
    }
    @GET
    @Path("getNewCinemaID")
     @Produces({ MediaType.APPLICATION_JSON})
    public Object getNewCinemaID(@PathParam("cinemaId") Integer cinemaId){
        Query query = em.createNamedQuery("Cinema.getLastCinemaID");
        List<Cinema> c = query.getResultList();
        int cinemaId1 = c.get(0).getCinemaId();
         JsonObject cinemaObject = Json.createObjectBuilder().add("cinemaId",cinemaId1).build();
         return cinemaObject;
    }

     @GET
    @Path("getAllCinemaname")
    @Produces(MediaType.APPLICATION_JSON)
    public Object getAllCinemaname(){
      List<String> queryList;
        queryList = em.createQuery(
                "SELECT c.cinemaName FROM Cinema c ",
                String.class)
                .getResultList();

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for (String row : queryList) {
                 JsonObject personObject = Json.createObjectBuilder()
                    .add("cinemaname",row)
                    .build();
            arrayBuilder.add(personObject);
        }
        JsonArray jArray = arrayBuilder.build();
        return jArray;
    }
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
