/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import Assign1.Credentials;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author wuyu327
 */
@Stateless
@Path("assign1.credentials")
public class CredentialsFacadeREST extends AbstractFacade<Credentials> {

    @PersistenceContext(unitName = "Assignment1PU")
    private EntityManager em;

    public CredentialsFacadeREST() {
        super(Credentials.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Credentials entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Credentials entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Credentials find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    
    @GET
    @Path("task3_a_findByUsername/{username}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> task3_a_findByUsername(@PathParam("username") String username){
        Query query = em.createNamedQuery("Credentials.task3_a_findByUsername");
        query.setParameter("username",username);
        return query.getResultList();
    }
    
    @GET
    @Path("task3_a_findByPasswordHash/{passwordHash}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> task3_a_findByPasswordHash(@PathParam("passwordHash") String passwordHash){
        Query query = em.createNamedQuery("Credentials.task3_a_findByPasswordHash");
        query.setParameter("passwordHash",passwordHash);
        return query.getResultList();
    }
    
    @GET
    @Path("task3_a_findBySignupDate/{signupDate}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> task3_a_findBySignupDate(@PathParam("signupDate") String signupDate) throws ParseException{
        Query query = em.createNamedQuery("Credentials.task3_a_findBySignupDate");
        DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        Date date = fmt.parse(signupDate);
        query.setParameter("signupDate",date);
        return query.getResultList();
    }
    
    @GET
    @Path("getPasswordAndUserName/{username}/{passwordHash}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> getPasswordAndUserName(@PathParam("username") String username,@PathParam("passwordHash") String passwordHash){
        Query query = em.createNamedQuery("Credentials.getPasswordAndUserName");
        query.setParameter("username",username);
        query.setParameter("passwordHash",passwordHash);
  
        return query.getResultList();
    }
    
    @GET
    @Path("getAllUsername")
    @Produces(MediaType.APPLICATION_JSON)
    public Object getAllUsername(){
      List<String> queryList;
        queryList = em.createQuery(
                "SELECT c.username FROM Credentials c ",
                String.class)
                .getResultList();

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for (String row : queryList) {
                 JsonObject personObject = Json.createObjectBuilder()
                    .add("username",row)
                    .build();
            arrayBuilder.add(personObject);
        }
        JsonArray jArray = arrayBuilder.build();
        return jArray;
    }
    
    @GET
    @Path("getLastCredentialsID")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Credentials> getLastCredentialsID(){
        Query query = em.createNamedQuery("Credentials.getLastCredentialsID");
        return query.getResultList();
    }
    @GET
    @Path("getNewCredentialsID")
     @Produces({ MediaType.APPLICATION_JSON})
    public Object getNewCredentialsID(@PathParam("credentialId") Integer credentialId){
        Query query = em.createNamedQuery("Credentials.getLastCredentialsID");
        List<Credentials> c = query.getResultList();
        int credentialid1 = c.get(0).getCredentialId();
         JsonObject credentialObject = Json.createObjectBuilder().add("credentialId",credentialid1).build();
         return credentialObject;
    }
    
    @Override
    protected EntityManager getEntityManager() {
        return em;
    }
    
}
