/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import Assign1.Memoir;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.ejb.Stateless;
import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author wuyu327
 */
@Stateless
@Path("assign1.memoir")
public class MemoirFacadeREST extends AbstractFacade<Memoir> {

    @PersistenceContext(unitName = "Assignment1PU")
    private EntityManager em;

    public MemoirFacadeREST() {
        super(Memoir.class);
    }

    @POST
    @Override
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void create(Memoir entity) {
        super.create(entity);
    }

    @PUT
    @Path("{id}")
    @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public void edit(@PathParam("id") Integer id, Memoir entity) {
        super.edit(entity);
    }

    @DELETE
    @Path("{id}")
    public void remove(@PathParam("id") Integer id) {
        super.remove(super.find(id));
    }

    @GET
    @Path("{id}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Memoir find(@PathParam("id") Integer id) {
        return super.find(id);
    }

    @GET
    @Override
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> findAll() {
        return super.findAll();
    }

    @GET
    @Path("{from}/{to}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> findRange(@PathParam("from") Integer from, @PathParam("to") Integer to) {
        return super.findRange(new int[]{from, to});
    }

    @GET
    @Path("task3_a_findByMovieName/{movieName}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> task3_a_findByMovieName(@PathParam("movieName") String movieName) {
        Query query = em.createNamedQuery("Memoir.task3_a_findByMovieName");
        query.setParameter("movieName", movieName);
        return query.getResultList();
    }

    @GET
    @Path("task3_a_findByMovieReleaseDate/{movieReleaseDate}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> task3_a_findByMovieReleaseDate(@PathParam("movieReleaseDate") String movieReleaseDate) throws ParseException {
        Query query = em.createNamedQuery("Memoir.task3_a_findByMovieReleaseDate");
        DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        Date date = fmt.parse(movieReleaseDate);
        query.setParameter("movieReleaseDate", date);
        return query.getResultList();
    }

    @GET
    @Path("task3_a_findByWatchDate/{watchDate}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> task3_a_findByWatchDate(@PathParam("watchDate") String watchDate) throws ParseException {
        Query query = em.createNamedQuery("Memoir.task3_a_findByWatchDate");
        DateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
        Date date = fmt.parse(watchDate);
        query.setParameter("watchDate", date);
        return query.getResultList();
    }

    @GET
    @Path("task3_a_findByWatchTime/{watchTime}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> task3_a_findByWatchTime(@PathParam("watchTime") String watchTime) throws ParseException {
        Query query = em.createNamedQuery("Memoir.task3_a_findByWatchTime");
        DateFormat fmt = new SimpleDateFormat("HH:mm:ss");
        Date date = fmt.parse(watchTime);
        query.setParameter("watchTime", date);
        return query.getResultList();
    }

    @GET
    @Path("task3_a_findByComment/{comment}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> task3_a_findByComment(@PathParam("comment") String comment) {
        Query query = em.createNamedQuery("Memoir.task3_a_findByComment");
        query.setParameter("comment", comment);
        return query.getResultList();
    }

    @GET
    @Path("task3_a_findByRatingScore/{ratingScore}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> task3_a_findByRatingScore(@PathParam("ratingScore") String ratingScore) {
        Query query = em.createNamedQuery("Memoir.task3_a_findByRatingScore");
        BigDecimal bd = new BigDecimal(ratingScore);
        query.setParameter("ratingScore", bd);
        return query.getResultList();
    }

    @GET
    @Path("task3_a_findByCinemaId/{cinemaId}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> task3_a_findByCinemaId(@PathParam("cinemaId") Integer cinemaId) {
        Query query = em.createNamedQuery("Memoir.task3_a_findByCinemaId");
        query.setParameter("cinemaId", cinemaId);
        return query.getResultList();
    }

    @GET
    @Path("task3_a_findByPersonId/{personId}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> task3_a_findByPersonId(@PathParam("personId") Integer personId) {
        Query query = em.createNamedQuery("Memoir.task3_a_findByPersonId");
        query.setParameter("personId", personId);
        return query.getResultList();
    }

    @GET
    @Path("task3_c_combinationOfTwoDifferentTable/{movieName}/{cinemaName}")
    @Produces({MediaType.APPLICATION_JSON})
    public List<Memoir> task3_c_combinationOfTwoDifferentTable(
            @PathParam("movieName") String movieName,
            @PathParam("cinemaName") String cinemaName) {
        TypedQuery<Memoir> query;
        query = em.createQuery(
                "SELECT m FROM Memoir m where m.movieName = :moviename and m.cinemaId.cinemaName = :cinemaName",
                Memoir.class);
        query.setParameter("moviename", movieName);
        query.setParameter("cinemaName", cinemaName);
        return query.getResultList();
    }

    @GET
    @Path("task3_d_combinationOfTwoTableStaticQuery/{movieName}/{cinemaName}")
    @Produces({MediaType.APPLICATION_JSON})
    public List<Memoir> task3_d_combinationOfTwoTableStaticQuery(
            @PathParam("movieName") String movieName,
            @PathParam("cinemaName") String cinemaName) {
        Query query;
        query = em.createNamedQuery("Memoir.task3_d_combinationOfTwoTableStaticQuery");
        query.setParameter("moviename", movieName);
        query.setParameter("cinemaName", cinemaName);
        return query.getResultList();
    }

    @GET
    @Path("task4_a_numberOfMoviesWatchedPerPostcode/{personId}/{startingDate}/{endingDate}")
    @Produces({MediaType.APPLICATION_JSON})
    public Object task4_a_numberOfMoviesWatchedPerPostcode(
            @PathParam("personId") Integer personId,
            @PathParam("startingDate") String startingDate,
            @PathParam("endingDate") String endingDate) throws ParseException {
        DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
        Date startDate = date.parse(startingDate);
        Date endDate = date.parse(endingDate);
        List<Object[]> queryList;
        queryList = em.createQuery(
                "SELECT m.cinemaId.cinemaPostcode, count(m.memoirId) FROM Memoir m WHERE m.personId.personId = :personId and m.watchDate between :startDate and :endDate GROUP BY m.cinemaId.cinemaPostcode",
                Object[].class).setParameter("personId", personId)
                .setParameter("startDate", startDate)
                .setParameter("endDate", endDate)
                .getResultList();

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for (Object[] row : queryList) {
            JsonObject personObject = Json.createObjectBuilder()
                    .add("cinemaPostCode", (String) row[0])
                    .add("numberOfMovies", (Long) row[1]).build();
            arrayBuilder.add(personObject);
        }

        JsonArray jArray = arrayBuilder.build();
        return jArray;
    }

    @GET
    @Path("task4_b_numberOfMoviesWatchedPerMonth/{personId}/{year}")
    @Produces(MediaType.APPLICATION_JSON)
    public Object task4_b_numberOfMoviesWatchedPerMonth(
            @PathParam("personId") Integer personId,
            @PathParam("year") Integer year) throws ParseException {

        List<Object[]> queryList;
        queryList = em.createQuery(
                "SELECT EXTRACT(MONTH FROM m.watchDate), count(m.memoirId) FROM Memoir m WHERE m.personId.personId = :personId and EXTRACT(YEAR FROM m.watchDate) = :year GROUP BY EXTRACT(MONTH FROM m.watchDate)",
                Object[].class).setParameter("personId", personId)
                .setParameter("year", year)
                .getResultList();

        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for (Object[] row : queryList) {
            String monthName = DateFormatSymbols.getInstance(Locale.ENGLISH).getMonths()[(Integer) row[0] - 1];
            System.out.print(row[0]);
            JsonObject personObject = Json.createObjectBuilder()
                    .add("WatchMonth", monthName)
                    .add("numberOfMovies", (Long) row[1]).build();

            arrayBuilder.add(personObject);
        }

        JsonArray jArray = arrayBuilder.build();
        return jArray;
    }

    @GET
    @Path("task4_c_highestScoreMovie/{personId}")
    @Produces({MediaType.APPLICATION_JSON})
    public Object task4_c_highestScoreMovie(
            @PathParam("personId") Integer personId) {

        List<Object[]> queryList;
        queryList = em.createQuery(
                "SELECT m.movieName, m.ratingScore,m.movieReleaseDate FROM Memoir m WHERE m.personId.personId = :personId and m.ratingScore = (select max(m.ratingScore) from Memoir m where m.personId.personId = :personId)",
                Object[].class).setParameter("personId", personId)
                .getResultList();
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for (Object[] row : queryList) {
            DateFormat date = new SimpleDateFormat("yyyy-MM-dd");
            String releaseDate = date.format(row[2]);
            JsonObject personObject = Json.createObjectBuilder()
                    .add("movieName", (String) row[0])
                    .add("highestRatingScore", (BigDecimal) row[1])
                    .add("releaseDate", releaseDate)
                    .build();
            arrayBuilder.add(personObject);
        }
        JsonArray jArray = arrayBuilder.build();
        return jArray;
    }

    @GET
    @Path("task4_d_listOfSameReleaseYearAndWatchYear/{personId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Object task4_d_listOfSameReleaseYearAndWatchYear(
            @PathParam("personId") Integer personId) {
        List<Object[]> queryList;
        queryList = em.createQuery(
                "SELECT m.movieName,EXTRACT(YEAR FROM m.movieReleaseDate) "
                + "FROM Memoir m "
                + "WHERE m.personId.personId = :personId "
                + "and EXTRACT(YEAR FROM m.watchDate) = EXTRACT(YEAR FROM m.movieReleaseDate) ",
                Object[].class).setParameter("personId", personId)
                .getResultList();
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for (Object[] row : queryList) {
            JsonObject personObject = Json.createObjectBuilder()
                    .add("MovieName", (String) row[0].toString())
                    .add("Year", (Integer) row[1])
                    .build();
            arrayBuilder.add(personObject);
        }
        JsonArray jArray = arrayBuilder.build();
        return jArray;
    }

    @GET
    @Path("task4_e_remakeMovieaAndYear/{personId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Object task4_e_remakeMovieaAndYear(
            @PathParam("personId") Integer personId) {
        List<Object[]> queryList;
        queryList = em.createQuery(
                "SELECT m.movieName,EXTRACT(YEAR FROM m.movieReleaseDate) FROM Memoir m "
                + "WHERE m.personId.personId = :personId "
                + "and m.movieName in "
                + "(SELECT m.movieName from Memoir m WHERE m.personId.personId = :personId group by m.movieName having count(m.movieName)>1)",
                Object[].class).setParameter("personId", personId)
                .getResultList();
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for (Object[] row : queryList) {
            JsonObject personObject = Json.createObjectBuilder()
                    .add("MovieName", (String) row[0].toString())
                    .add("Year", (Integer) row[1])
                    .build();
            arrayBuilder.add(personObject);
        }
        JsonArray jArray = arrayBuilder.build();
        return jArray;
    }

    @GET
    @Path("task4_f_top5MovieInRecenYear/{personId}")
    @Produces(MediaType.APPLICATION_JSON)
    public Object task4_f_top5MovieInRecenYear(
            @PathParam("personId") Integer personId) {
        List<Object[]> queryList;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        int recentYear = calendar.get(Calendar.YEAR);
        queryList = em.createQuery(
                "SELECT m.movieName,m.movieReleaseDate,m.ratingScore "
                + "FROM Memoir m "
                + "WHERE m.personId.personId = :personId and EXTRACT(YEAR FROM m.movieReleaseDate) = :recentYear "
                + "order by m.ratingScore desc",
                Object[].class).setParameter("personId", personId)
                .setParameter("recentYear", recentYear)
                .setMaxResults(5)
                .getResultList();
        JsonArrayBuilder arrayBuilder = Json.createArrayBuilder();
        for (Object[] row : queryList) {
            JsonObject personObject = Json.createObjectBuilder()
                    .add("MovieName", (String) row[0].toString())
                    .add("ReleaseDate", format.format(row[1]))
                    .add("RatingScore", (BigDecimal) row[2])
                    .build();
            arrayBuilder.add(personObject);
        }
        JsonArray jArray = arrayBuilder.build();
        return jArray;
    }
    
    
    @GET
    @Path("getLastMemoirID")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public List<Memoir> getLastMemoirID(){
        Query query = em.createNamedQuery("Memoir.getLastMemoirID");
        return query.getResultList();
    }
    @GET
    @Path("getNewMemoirID")
     @Produces({ MediaType.APPLICATION_JSON})
    public Object getNewMemoirID(@PathParam("memoirId") Integer memoirId){
        Query query = em.createNamedQuery("Memoir.getLastMemoirID");
        List<Memoir> m = query.getResultList();
        int memoirID1 = m.get(0).getMemoirId();
         JsonObject memoirObject = Json.createObjectBuilder().add("memoirId",memoirID1).build();
         return memoirObject;
    }
    

    @GET
    @Path("count")
    @Produces(MediaType.TEXT_PLAIN)
    public String countREST() {
        return String.valueOf(super.count());
    }

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

}
